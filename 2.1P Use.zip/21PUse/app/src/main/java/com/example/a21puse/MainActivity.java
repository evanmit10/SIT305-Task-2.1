package com.example.a21puse;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.ActionBar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Arrays;



public class MainActivity extends AppCompatActivity {

    private Spinner categorySpinner;
    private Spinner sourceUnitSpinner;
    private Spinner destinationUnitSpinner;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        categorySpinner = findViewById(R.id.category_spinner);
        sourceUnitSpinner = findViewById(R.id.source_unit_spinner);
        destinationUnitSpinner = findViewById(R.id.destination_unit_spinner);

        String[] categories = new String[] {"Length", "Weight", "Temperature"};
        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, categories);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);

        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCategory = categories[position];
                ArrayAdapter<CharSequence> adapter;

                switch (selectedCategory) {
                    case "Length":
                        adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.lengthUnits, android.R.layout.simple_spinner_item);
                        break;
                    case "Weight":
                        adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.weightUnits, android.R.layout.simple_spinner_item);
                        break;
                    case "Temperature":
                        adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.temperatureUnits, android.R.layout.simple_spinner_item);
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + selectedCategory);
                }

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                sourceUnitSpinner.setAdapter(adapter);
                destinationUnitSpinner.setAdapter(adapter);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //nothing selected
            }
        });

        EditText inputValue = findViewById(R.id.input_value);
        Button convertButton = findViewById(R.id.convert_button);
        TextView resultValue = findViewById(R.id.result_value);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sourceUnit = sourceUnitSpinner.getSelectedItem().toString();
                String destinationUnit = destinationUnitSpinner.getSelectedItem().toString();
                String input = inputValue.getText().toString();

                if (input.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter a valid value", Toast.LENGTH_SHORT).show();
                    return;
                }

                double inputValue = Double.parseDouble(input);
                double result = convert(sourceUnit, destinationUnit, inputValue);
                String resultText = String.format("Result: %.2f %s", result, destinationUnit);
                resultValue.setText(resultText);

            }

        });

    }

    private double length(String sourceUnit, String destinationUnit, double inputValue) {
        double result = 0;

        switch (sourceUnit) {
            case "inch":
                result = inputValue * 2.54;
                break;
            case "foot":
                result = inputValue * 30.48;
                break;
            case "yard":
                result = inputValue * 91.44;
                break;
            case "mile":
                result = inputValue * 160934;
                break;
        }

        switch (destinationUnit) {
            case "inch":
                result /=  2.54;
                break;
            case "foot":
                result /= 30.48;
                break;
            case "yard":
                result /= 91.44;
                break;
            case "mile":
                result /= 160934;
                break;
        }
        return result;

    }

    private double weight(String sourceUnit, String destinationUnit, double inputValue) {
        double result = 0;

        switch (sourceUnit) {
            case "pound":
                result = inputValue * 453.592;
                break;
            case "ounce":
                result = inputValue * 28.3495;
                break;
            case "ton":
                result = inputValue * 907185;
                break;
        }

        switch (destinationUnit) {
            case "pound":
                result /= 453.592;
                break;
            case "ounce":
                result /= 28.3495;
                break;
            case "ton":
                result /= 907185;
                break;
        }
        return result;

    }
    private double temperature(String sourceUnit, String destinationUnit, double inputValue) {
        double result = 0;

        switch (sourceUnit) {
            case "Fahrenheit":
                result = (inputValue - 32)/1.8;
                break;
            case "Kelvin":
                result = inputValue - 273.15;
                break;
            case "Celsius":
                result = inputValue;
                break;
        }

        switch (destinationUnit) {
            case "Fahrenheit":
                result = (result * 1.8) + 32;
                break;
            case "Kelvin":
                result += 273.15;
                break;
            case "Celsius":
                break;
        }
        return result;

    }

    private double convert(String sourceUnit, String destinationUnit, double inputValue)
    {
        if (Arrays.asList("inch", "foot", "yard", "mile").contains(sourceUnit))
        {
            return length(sourceUnit, destinationUnit, inputValue);
        }
        else if (Arrays.asList("pound", "ounce", "ton").contains(sourceUnit))
        {
            return weight(sourceUnit, destinationUnit, inputValue);
        }
        else
        {
            return temperature(sourceUnit, destinationUnit, inputValue);
        }
    }
}